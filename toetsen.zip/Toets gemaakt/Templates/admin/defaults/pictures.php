<figure>
    <img class="banner-img img-fluid" src='/img/header2.jpg' />
</figure>


