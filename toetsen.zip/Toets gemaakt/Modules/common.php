<?php

function getTitle() {
    global $title, $titleSuffix;
    return $title . $titleSuffix;
}