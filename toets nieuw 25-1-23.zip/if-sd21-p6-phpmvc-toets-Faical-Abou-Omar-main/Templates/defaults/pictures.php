<figure>
    <img class="banner-img img-fluid" src='/img/header1.jpg' />
</figure>


